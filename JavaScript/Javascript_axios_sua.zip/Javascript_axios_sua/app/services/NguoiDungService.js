function NguoiDungService() {
  this.getListUserApi = function () {
    /**
     *  axios trả về đối tượng Promises (lời hứa)
     *  Promises (lời hứa):
     *      - Pending (Chờ)
     *      - Resolve: Lời hứa thực hiện dc (thành công) - then
     *      - Reject: Thất hứa (thất bại) - catch
     */
    return axios({
      //key: value
      url: "https://5a6451dcf2bae00012ca1a6a.mockapi.io/api/NguoiDung",
      method: "GET",
    });
  };

  this.deleteUserApi = function (id) {
    return axios({
      url: `https://5a6451dcf2bae00012ca1a6a.mockapi.io/api/NguoiDung/${id}`,
      method: "DELETE",
    });
  };
}
