var service = new NguoiDungService();

showListUser();

getEle("btnThemNguoiDung").addEventListener("click", function () {
  document.getElementsByClassName("modal-title")[0].innerHTML =
    "Thêm người dùng";

  var footerModal =
    "<button class='btn btn-success' onclick='addUser()'>Add User</button>";

  document.getElementsByClassName("modal-footer")[0].innerHTML = footerModal;
});

function showListUser() {
  service
    .getListUserApi()
    .then(function (result) {
      createTable(result.data);
    })
    .catch(function (err) {
      console.log(err);
    });
}

function createTable(listUser) {
  var content = "";
  listUser.map(function (user, index) {
    content += `
            <tr>
                <td>${index + 1}</td>
                <td>${user.taiKhoan}</td>
                <td>${user.matKhau}</td>
                <td>${user.hoTen}</td>
                <td>${user.email}</td>
                <td>${user.soDT}</td>
                <td>${user.maLoaiNguoiDung}</td>
                <td>
                    <button class="btn btn-info" data-toggle="modal" data-target="#myModal" onclick="editUser(${
                      user.id
                    })">Sửa</button>
                    <button class="btn btn-danger" onclick="deleteUser(${
                      user.id
                    })">Xóa</button>
                </td>
            </tr>
        `;
  });
  getEle("tblDanhSachNguoiDung").innerHTML = content;
}

/**
 * Sửa người dùng
 */
function editUser(id) {
  document.getElementsByClassName("modal-title")[0].innerHTML =
    "Sửa người dùng";
  var footerModal =
    "<button class='btn btn-success' onclick='updateUser()'>Update User</button>";
  document.getElementsByClassName("modal-footer")[0].innerHTML = footerModal;
}

/**
 * Xóa User
 */
function deleteUser(id) {
  service
    .deleteUserApi(id)
    .then(function (result) {
      alert("Xoa thanh cong");
      showListUser();
    })
    .catch(function (err) {
      console.log(err);
    });
}

function getEle(id) {
  return document.getElementById(id);
}
