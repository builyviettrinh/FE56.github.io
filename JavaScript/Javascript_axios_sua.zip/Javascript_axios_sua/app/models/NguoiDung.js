function NguoiDung(
  _id,
  _taiKhoan,
  _hoTen,
  _matKhau,
  _email,
  _soDt,
  _maLoaiNguoiDung
) {
  //key = value
  this.id = _id;
  this.taiKhoan = _taiKhoan;
  this.hoTen = _hoTen;
  this.matKhau = _matKhau;
  this.email = _email;
  this.soDT = _soDt;
  this.maLoaiNguoiDung = _maLoaiNguoiDung;
}
